package rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * Created by Kees on 08/03/2017.
 */
@ApplicationPath("api")
public class JAXRSconfig extends Application{

}
