package DAO;

import domain.Tweet;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by Kees on 15/03/2017.
 */
public class TweetDAOTest {

    @Test
    public void allTweets() throws Exception {
        return;
    }

    @Test
    public void saveTweet() throws Exception {
        return;
    }

    @Test
    public void removeUser() throws Exception {
        return;
    }

}