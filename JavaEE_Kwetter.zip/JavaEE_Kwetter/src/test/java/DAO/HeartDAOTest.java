package DAO;

import domain.Heart;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by Kees on 15/03/2017.
 */
public class HeartDAOTest {

    @Test
    public void allHearts() throws Exception {
        return;
    }

    @Test
    public void saveHeart() throws Exception {
        return;
    }

    @Test
    public void removeHeart() throws Exception {
        return;
    }

}