package DAO;

import domain.Mention;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by Kees on 15/03/2017.
 */
public class MentionDAOTest {

    @Test
    public void allMentions() throws Exception {
        return;
    }

    @Test
    public void saveMention() throws Exception {
        return;
    }

    @Test
    public void removeMention() throws Exception {
        return;
    }

}