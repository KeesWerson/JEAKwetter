package rest;

import static org.junit.Assert.*;

/**
 * Created by Kees on 08/03/2017.
 */
public class UserResourceTest {

}